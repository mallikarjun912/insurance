package com.insurance.quote;


/**
 * Unit test for simple App.
 */
public class AppTest {
   
}
