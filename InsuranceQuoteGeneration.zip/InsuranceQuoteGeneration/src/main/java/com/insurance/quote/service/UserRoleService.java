package com.insurance.quote.service;

import com.insurance.quote.entity.UserRole;

public interface UserRoleService {
	public UserRole findUser(String username,String password);
	public void saveUser(UserRole user);
}
