package com.insurance.quote.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="business_segment")
public class BusinessSegment {
	@Id
	//@GeneratedValue(strategy = GenerationType.)
	@Column(length=10)
	private String bus_seg_id;
	@Column
	private int bus_seg_seq;
	@Column(length=20)
	private String bus_seg_name;
	
	public BusinessSegment() {
		// TODO Auto-generated constructor stub
	}

	public BusinessSegment(String bus_seg_id, int bus_seg_seq, String bus_seg_name) {
		this.bus_seg_id = bus_seg_id;
		this.bus_seg_seq = bus_seg_seq;
		this.bus_seg_name = bus_seg_name;
	}

	public String getBus_seg_id() {
		return bus_seg_id;
	}

	public void setBus_seg_id(String bus_seg_id) {
		this.bus_seg_id = bus_seg_id;
	}

	public int getBus_seg_seq() {
		return bus_seg_seq;
	}

	public void setBus_seg_seq(int bus_seg_seq) {
		this.bus_seg_seq = bus_seg_seq;
	}

	public String getBus_seg_name() {
		return bus_seg_name;
	}

	public void setBus_seg_name(String bus_seg_name) {
		this.bus_seg_name = bus_seg_name;
	}

	@Override
	public String toString() {
		return "BusinessSegment [bus_seg_id=" + bus_seg_id + ", bus_seg_seq=" + bus_seg_seq + ", bus_seg_name="
				+ bus_seg_name + "]";
	}
	
}
