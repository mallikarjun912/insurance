package com.insurance.quote.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name="accounts")
public class Accounts {
	@Id
	private int accountNumber;
	@Column(length=30)
	private String insuredName;
	@Column(length=30)
	private String insuredStreet;
	@Column(length=30)
	private String insuredCity;
	@Column(length=30)
	private String insuredState;
	@Column(length=30)
	private int insuredZip;
	@Column(length=20)
	private String business_Segment;
	
	@OneToOne
	private UserRole userrole;
	public Accounts() {
		
	}

	public Accounts(int accountNumber, String insuredName, String insuredStreet, String insuredCity,
			String insuredState, int insuredZip, String business_Segment, UserRole userrole) {
		this.accountNumber = accountNumber;
		this.insuredName = insuredName;
		this.insuredStreet = insuredStreet;
		this.insuredCity = insuredCity;
		this.insuredState = insuredState;
		this.insuredZip = insuredZip;
		this.business_Segment = business_Segment;
		this.userrole = userrole;
	}

	public int getAccountNumber() {
		return accountNumber;
	}

	public void setAccountNumber(int accountNumber) {
		this.accountNumber = accountNumber;
	}

	public String getInsuredName() {
		return insuredName;
	}

	public void setInsuredName(String insuredName) {
		this.insuredName = insuredName;
	}

	public String getInsuredStreet() {
		return insuredStreet;
	}

	public void setInsuredStreet(String insuredStreet) {
		this.insuredStreet = insuredStreet;
	}

	public String getInsuredCity() {
		return insuredCity;
	}

	public void setInsuredCity(String insuredCity) {
		this.insuredCity = insuredCity;
	}

	public String getInsuredState() {
		return insuredState;
	}

	public void setInsuredState(String insuredState) {
		this.insuredState = insuredState;
	}

	public int getInsuredZip() {
		return insuredZip;
	}

	public void setInsuredZip(int insuredZip) {
		this.insuredZip = insuredZip;
	}

	public String getBusiness_Segment() {
		return business_Segment;
	}

	public void setBusiness_Segment(String business_Segment) {
		this.business_Segment = business_Segment;
	}
	public void setUserrole(UserRole userrole) {
		this.userrole = userrole;
	}
	public UserRole getUserrole() {
		return userrole;
	}

	@Override
	public String toString() {
		return "Accounts [accountNumber=" + accountNumber + ", insuredName=" + insuredName + ", insuredStreet="
				+ insuredStreet + ", insuredCity=" + insuredCity + ", insuredState=" + insuredState + ", insuredZip="
				+ insuredZip + ", business_Segment=" + business_Segment + ", userrole=" + userrole + "]";
	}
	

}
