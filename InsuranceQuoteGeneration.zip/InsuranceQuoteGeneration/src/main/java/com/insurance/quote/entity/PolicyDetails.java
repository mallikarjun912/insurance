package com.insurance.quote.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name="policydetails")
public class PolicyDetails {
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int id;
	@OneToOne
	private Policy policy;
	@Column(length=10)
	private String questionId;
	@Column(length=30)
	private String answer;
	
	public PolicyDetails() {
		// TODO Auto-generated constructor stub
	}

	public PolicyDetails(Policy policy, String questionId, String answer) {
		this.policy = policy;
		this.questionId = questionId;
		this.answer = answer;
	}

	public Policy getPolicy() {
		return policy;
	}

	public void setPolicy(Policy policy) {
		this.policy = policy;
	}

	public String getQuestionId() {
		return questionId;
	}

	public void setQuestionId(String questionId) {
		this.questionId = questionId;
	}

	public String getAnswer() {
		return answer;
	}

	public void setAnswer(String answer) {
		this.answer = answer;
	}

	@Override
	public String toString() {
		return "PolicyDetails [policy=" + policy + ", questionId=" + questionId + ", answer=" + answer + "]";
	}

}
