package com.insurance.quote.service;

import java.util.List;

import com.insurance.quote.dto.PolicyQuestionsDto;
import com.insurance.quote.entity.BusinessSegment;
import com.insurance.quote.entity.PolicyQuestions;

public interface PolicyQuestionsService {
	public List<PolicyQuestions> findAll();
	public void addQuestions(PolicyQuestionsDto questions);
	public BusinessSegment findBySegId(String seg_id);
}
