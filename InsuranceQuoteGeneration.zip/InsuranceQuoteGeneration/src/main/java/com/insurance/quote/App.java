package com.insurance.quote;

/**
 * Hello world!
 *
 */
public class App 
{
    
}
