package com.insurance.quote.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.insurance.quote.entity.UserRole;

@Repository
public interface UserRoleDao extends JpaRepository<UserRole,String>{
	@Query(value="from UserRole user where user.username=?1 and user.password=?2")
	public UserRole findUser(String username, String password);
}
