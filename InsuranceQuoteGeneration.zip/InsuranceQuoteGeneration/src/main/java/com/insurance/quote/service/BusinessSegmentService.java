package com.insurance.quote.service;

import java.util.List;

import com.insurance.quote.entity.BusinessSegment;

public interface BusinessSegmentService {
	public List<BusinessSegment> findAll();
	public void save(BusinessSegment segment);
	public void updateSegment(BusinessSegment segment);
	public void deleteSegement(String bus_seg_id);
	public BusinessSegment findBySegId(String seg_id);
}
