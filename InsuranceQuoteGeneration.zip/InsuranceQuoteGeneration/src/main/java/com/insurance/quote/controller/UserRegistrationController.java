package com.insurance.quote.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.insurance.quote.entity.UserRole;
import com.insurance.quote.service.UserRoleService;

@CrossOrigin(origins="http://localhost:3000")
@RestController
@RequestMapping("/register")
public class UserRegistrationController {
	@Autowired
	UserRoleService regservice;
	
	@PostMapping
	public ResponseEntity<String> registerUser(@RequestBody UserRole user){
		System.out.println(user.getUsername()+user.getPassword()+user.getRole());  
		regservice.saveUser(user);
		return new ResponseEntity<String>(HttpStatus.OK);
	}
}
