package com.insurance.quote.entity;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name="policyquestions")
public class PolicyQuestions {
	@Id
	@Column(length=10)
	private String pol_ques_id;
	@Column
	private int pol_ques_seq;
	@OneToOne(targetEntity=com.insurance.quote.entity.BusinessSegment.class, cascade=CascadeType.ALL)
	@JoinColumn(name="bus_seg_id",referencedColumnName="bus_seg_id")
	private BusinessSegment businessSegment;
	@Column(length=80)
	private String pol_ques_desc;
	@Column(length=30)
	private String pol_ques_ans1;
	@Column
	private int pol_ques_ans1_weightage;
	@Column(length=30)
	private String pol_ques_ans2;
	@Column
	private int pol_ques_ans2_weightage;
	@Column(length=30)
	private String pol_ques_ans3;
	@Column
	private int pol_ques_ans3_weightage;
		
	public PolicyQuestions() {
		// TODO Auto-generated constructor stub
	}

	public PolicyQuestions(String pol_ques_id, int pol_ques_seq, BusinessSegment businessSegment, String pol_ques_desc,
			String pol_ques_ans1, int pol_ques_ans1_weightage, String pol_ques_ans2, int pol_ques_ans2_weightage,
			String pol_ques_ans3, int pol_ques_ans3_weightage) {
		this.pol_ques_id = pol_ques_id;
		this.pol_ques_seq = pol_ques_seq;
		this.businessSegment = businessSegment;
		this.pol_ques_desc = pol_ques_desc;
		this.pol_ques_ans1 = pol_ques_ans1;
		this.pol_ques_ans1_weightage = pol_ques_ans1_weightage;
		this.pol_ques_ans2 = pol_ques_ans2;
		this.pol_ques_ans2_weightage = pol_ques_ans2_weightage;
		this.pol_ques_ans3 = pol_ques_ans3;
		this.pol_ques_ans3_weightage = pol_ques_ans3_weightage;
	}

	public String getPol_ques_id() {
		return pol_ques_id;
	}

	public void setPol_ques_id(String pol_ques_id) {
		this.pol_ques_id = pol_ques_id;
	}

	public int getPol_ques_seq() {
		return pol_ques_seq;
	}

	public void setPol_ques_seq(int pol_ques_seq) {
		this.pol_ques_seq = pol_ques_seq;
	}

	public BusinessSegment getBusinessSegment() {
		return businessSegment;
	}

	public void setBusinessSegment(BusinessSegment businessSegment) {
		this.businessSegment = businessSegment;
	}

	public String getPol_ques_desc() {
		return pol_ques_desc;
	}

	public void setPol_ques_desc(String pol_ques_desc) {
		this.pol_ques_desc = pol_ques_desc;
	}

	public String getPol_ques_ans1() {
		return pol_ques_ans1;
	}

	public void setPol_ques_ans1(String pol_ques_ans1) {
		this.pol_ques_ans1 = pol_ques_ans1;
	}

	public int getPol_ques_ans1_weightage() {
		return pol_ques_ans1_weightage;
	}

	public void setPol_ques_ans1_weightage(int pol_ques_ans1_weightage) {
		this.pol_ques_ans1_weightage = pol_ques_ans1_weightage;
	}

	public String getPol_ques_ans2() {
		return pol_ques_ans2;
	}

	public void setPol_ques_ans2(String pol_ques_ans2) {
		this.pol_ques_ans2 = pol_ques_ans2;
	}

	public int getPol_ques_ans2_weightage() {
		return pol_ques_ans2_weightage;
	}

	public void setPol_ques_ans2_weightage(int pol_ques_ans2_weightage) {
		this.pol_ques_ans2_weightage = pol_ques_ans2_weightage;
	}

	public String getPol_ques_ans3() {
		return pol_ques_ans3;
	}

	public void setPol_ques_ans3(String pol_ques_ans3) {
		this.pol_ques_ans3 = pol_ques_ans3;
	}

	public int getPol_ques_ans3_weightage() {
		return pol_ques_ans3_weightage;
	}

	public void setPol_ques_ans3_weightage(int pol_ques_ans3_weightage) {
		this.pol_ques_ans3_weightage = pol_ques_ans3_weightage;
	}

	
	@Override
	public String toString() {
		return "PolicyQuestions [pol_ques_id=" + pol_ques_id + ", pol_ques_seg=" + pol_ques_seq + ", businessSegment="
				+ businessSegment + ", pol_ques_desc=" + pol_ques_desc + ", pol_ques_ans1=" + pol_ques_ans1
				+ ", pol_ques_ans1_weightage=" + pol_ques_ans1_weightage + ", pol_ques_ans2=" + pol_ques_ans2
				+ ", pol_ques_ans2_weightage=" + pol_ques_ans2_weightage + ", pol_ques_ans3=" + pol_ques_ans3
				+ ", pol_ques_ans3_weightage=" + pol_ques_ans3_weightage + ", pol_ques_ans4="
				+ ", pol_ques_ans4_weightage=" + "]";
	}

}
