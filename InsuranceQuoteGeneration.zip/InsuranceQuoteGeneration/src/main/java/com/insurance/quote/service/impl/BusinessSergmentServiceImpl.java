package com.insurance.quote.service.impl;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.insurance.quote.dao.BusinessSegmentDao;
import com.insurance.quote.entity.BusinessSegment;
import com.insurance.quote.service.BusinessSegmentService;

@Transactional
@Service(value="businessSegmentService")
public class BusinessSergmentServiceImpl implements BusinessSegmentService{

	@Autowired
	BusinessSegmentDao dao;
	@Override
	public List<BusinessSegment> findAll() {
		return dao.findAll();
	}
	@Override
	public void  save(BusinessSegment segment) {
		 dao.save(segment);
	}
	@Override
	public void updateSegment(BusinessSegment segment) {
		BusinessSegment bs = findBySegId(segment.getBus_seg_id());
		if(bs != null)
			dao.save(segment);
	}
	@Override
	public void deleteSegement(String bus_seg_id) {
		dao.deleteById(bus_seg_id); 		
	}
	@Override
	public BusinessSegment findBySegId(String seg_id) {
		BusinessSegment segment = dao.findBySegmentId(seg_id);
		return segment;
	}

}
