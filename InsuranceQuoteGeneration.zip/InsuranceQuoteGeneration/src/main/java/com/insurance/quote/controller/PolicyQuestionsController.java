package com.insurance.quote.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.insurance.quote.dto.PolicyQuestionsDto;
import com.insurance.quote.entity.PolicyQuestions;
import com.insurance.quote.service.PolicyQuestionsService;

@CrossOrigin(origins="http://localhost:3000")
@RestController
@RequestMapping("/questions")
public class PolicyQuestionsController {
	@Autowired
	PolicyQuestionsService service;
	
	@GetMapping
	public  ResponseEntity<List<PolicyQuestions>> getPolicyQuestions(){
		List<PolicyQuestions> questionsList = service.findAll();
		return new ResponseEntity<List<PolicyQuestions>>(questionsList, new HttpHeaders(),HttpStatus.OK);
	}
	
	@PostMapping
	public ResponseEntity<String> addQuestions(@RequestBody PolicyQuestionsDto questions){
		
		System.out.println("ques-id "+questions.getPol_ques_id());
		System.out.println("seq  "+questions.getPol_ques_seq());
		System.out.println("desc "+questions.getPol_ques_desc());
		System.out.println("ans-1 "+questions.getPol_ques_ans1());
		System.out.println("ans-1 wt "+questions.getPol_ques_ans1_weightage());
		System.out.println("ans-2 "+questions.getPol_ques_ans2());
		System.out.println("ans-2 wt "+questions.getPol_ques_ans2_weightage());
		System.out.println("ans-3 "+questions.getPol_ques_ans3());
		System.out.println("ans-3 wt "+questions.getPol_ques_ans3_weightage());
		System.out.println("segment id "+questions.getBusiness_segment());
		service.addQuestions(questions);
		return new ResponseEntity<String>(HttpStatus.OK);
	}
}
