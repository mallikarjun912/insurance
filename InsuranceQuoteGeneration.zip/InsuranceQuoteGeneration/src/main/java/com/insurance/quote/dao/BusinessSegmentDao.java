package com.insurance.quote.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.insurance.quote.entity.BusinessSegment;

@Repository
public interface BusinessSegmentDao extends JpaRepository<BusinessSegment, String>{
	@Query(value="from BusinessSegment seg where seg.bus_seg_id=?1")
	public BusinessSegment findBySegmentId(String seg_id);
}
