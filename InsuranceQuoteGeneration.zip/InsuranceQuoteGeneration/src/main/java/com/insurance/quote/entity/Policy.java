package com.insurance.quote.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name="policy")
public class Policy {
	@Id
	@Column
	private int policyNumber;
	@Column
	private double policyPremium;
	@OneToOne
	private Accounts accounts;
	
	public Policy() {
		// TODO Auto-generated constructor stub
	}

	public Policy(int policyNumber, double policyPremium, Accounts accounts) {
		this.policyNumber = policyNumber;
		this.policyPremium = policyPremium;
		this.accounts = accounts;
	}

	public int getPolicyNumber() {
		return policyNumber;
	}

	public void setPolicyNumber(int policyNumber) {
		this.policyNumber = policyNumber;
	}

	public double getPolicyPremium() {
		return policyPremium;
	}

	public void setPolicyPremium(double policyPremium) {
		this.policyPremium = policyPremium;
	}

	public Accounts getAccounts() {
		return accounts;
	}

	public void setAccounts(Accounts accounts) {
		this.accounts = accounts;
	}

	@Override
	public String toString() {
		return "Policy [policyNumber=" + policyNumber + ", policyPremium=" + policyPremium + ", accounts=" + accounts
				+ "]";
	}

}
