package com.insurance.quote;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class InsuranceQuoteApp {

	public static void main(String[] args) {
		SpringApplication.run(InsuranceQuoteApp.class, args);
	}
}
