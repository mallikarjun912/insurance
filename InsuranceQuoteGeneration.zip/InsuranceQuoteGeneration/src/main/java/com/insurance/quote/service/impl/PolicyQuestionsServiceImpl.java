package com.insurance.quote.service.impl;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.insurance.quote.dao.BusinessSegmentDao;
import com.insurance.quote.dao.PolicyQuestionsDao;
import com.insurance.quote.dto.PolicyQuestionsDto;
import com.insurance.quote.entity.BusinessSegment;
import com.insurance.quote.entity.PolicyQuestions;
import com.insurance.quote.service.PolicyQuestionsService;

@Transactional
@Service(value="policyQuestionsService")
public class PolicyQuestionsServiceImpl implements PolicyQuestionsService{

	@Autowired
	PolicyQuestionsDao dao;
	@Autowired
	BusinessSegmentDao segmentDao;
	
	@Override
	public List<PolicyQuestions> findAll() {
		return dao.findAll();
	}

	@Override
	public void addQuestions(PolicyQuestionsDto dto) {
		PolicyQuestions questions = new PolicyQuestions();
		questions.setPol_ques_id(dto.getPol_ques_id());
		questions.setPol_ques_seq(dto.getPol_ques_seq());
		questions.setPol_ques_desc(dto.getPol_ques_desc());
		questions.setPol_ques_ans1(dto.getPol_ques_ans1());
		questions.setPol_ques_ans1_weightage(dto.getPol_ques_ans1_weightage());
		questions.setPol_ques_ans2(dto.getPol_ques_ans2());
		questions.setPol_ques_ans2_weightage(dto.getPol_ques_ans2_weightage());
		questions.setPol_ques_ans3(dto.getPol_ques_ans3());
		questions.setPol_ques_ans3_weightage(dto.getPol_ques_ans3_weightage());
		// Business segment object
		
		BusinessSegment segment = findBySegId(dto.getBusiness_segment());
		System.out.println("busi segment = "+segment.getBus_seg_id()+" "+segment.getBus_seg_name()); 
		questions.setBusinessSegment(segment); 
		dao.save(questions);		
	}

	@Override
	public BusinessSegment findBySegId(String seg_id) {
		BusinessSegment segment = segmentDao.findBySegmentId(seg_id);
		return segment;
	}

}
