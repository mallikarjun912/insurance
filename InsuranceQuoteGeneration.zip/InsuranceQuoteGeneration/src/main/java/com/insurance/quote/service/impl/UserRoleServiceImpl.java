package com.insurance.quote.service.impl;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.insurance.quote.dao.UserRoleDao;
import com.insurance.quote.entity.UserRole;
import com.insurance.quote.service.UserRoleService;

@Transactional
@Service(value="userRoleService")
public class UserRoleServiceImpl implements UserRoleService{
	@Autowired
	UserRoleDao dao;
	@Override
	public UserRole findUser(String username,String password) {
		return dao.findUser(username, password); 
	}
	@Override
	public void saveUser(UserRole user) {
		dao.save(user);
	}

}
