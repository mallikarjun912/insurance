package com.insurance.quote.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.insurance.quote.entity.BusinessSegment;
import com.insurance.quote.service.BusinessSegmentService;

@CrossOrigin(origins="http://localhost:3000")
@RestController
@RequestMapping("/segments")
public class BusinessSegmentController {
	@Autowired
	BusinessSegmentService segmentService;
	
	@GetMapping
	public ResponseEntity<List<BusinessSegment>> getBusinessSegments() {
		List<BusinessSegment> segments = segmentService.findAll();
		return new ResponseEntity<List<BusinessSegment>>(segments, new HttpHeaders(), HttpStatus.OK);
	}
	
	@GetMapping("/{seg_id}") 
	public ResponseEntity<BusinessSegment> getSegmentById(@PathVariable String seg_id){
		BusinessSegment segment = segmentService.findBySegId(seg_id);
		System.out.println("from getSegmentById()"); 
		return new ResponseEntity<BusinessSegment>(segment, new HttpHeaders(),HttpStatus.OK);
	}
	
	@PostMapping
	public ResponseEntity<String> addSegment(@RequestBody BusinessSegment segment){
		segmentService.save(segment);
		return new ResponseEntity<String>(HttpStatus.OK);
	}
	@PutMapping
	public ResponseEntity<String> updatedSegment(@RequestBody BusinessSegment segment){
		System.out.println(segment.getBus_seg_id());
		System.out.println(segment.getBus_seg_seq());
		System.out.println(segment.getBus_seg_name());
		segmentService.updateSegment(segment);
		return new ResponseEntity<String>(HttpStatus.OK);
	}
	@DeleteMapping("/{seg_id}") 
	public void deleteSegment(@PathVariable String seg_id) {
		segmentService.deleteSegement(seg_id);
	}
}
