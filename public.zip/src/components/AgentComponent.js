import React, { Component } from 'react';
import { connect } from 'react-redux';
import { Link } from 'react-router-dom';

class AgentComponent extends Component {
   
    render() {
        console.log("from AgentComponent  role : "+this.props.userrole.role);
        return(
            <div>
                 <h1>Welcome {this.props.userrole.username}</h1>
                 <Link to="/questions"> 
                    <button className="btn btn-link" id="bt"><h4>View Questions</h4> </button>
                </Link>
            </div>
        );
    }
}
function mapStateToProps(state) {
    return {
            userrole: state.LoginReducer.userrole
    };
}

export default connect(mapStateToProps)(AgentComponent);