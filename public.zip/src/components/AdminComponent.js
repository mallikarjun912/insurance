import React, { Component } from 'react';
import { connect } from 'react-redux';
// newly added
import { Link } from 'react-router-dom';


class AdminComponent extends Component {
    // remove onClick function and keep link tag
    // onClick() {
    //     window.location.href="/questions" 
    // }
    render(){
        console.log("frm AdminComponent  role : "+this.props.userrole.role);
        return(
            <div>
                <h1>Welcome Administrator </h1>
                <Link to="/questions"> 
                    <button className="btn btn-link" id="bt"><h4>View Questions</h4> </button>
                </Link>
             {/* <button className="btn btn-link" id="bt" onClick={this.onClick}><h4>View Questions</h4></button>                */}
            </div>
        );
    }
}

function mapStateToProps(state) {
    return {
		userrole: state.LoginReducer.userrole
	};
}
export default connect(mapStateToProps)(AdminComponent);