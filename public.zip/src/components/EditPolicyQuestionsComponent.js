import React, { Component } from "react";
import PolicyQuestionsService from '../service/PolicyQuestionsService';
class EditPolicyQuestionsComponent extends Component {
    constructor(props){
        super(props)
        this.state = {
            pol_ques_id :'',
            pol_ques_seq : '',
            pol_ques_desc : '',
            pol_ques_ans1 : '',
            pol_ques_ans1_weightage : '',
            pol_ques_ans2 : '',
            pol_ques_ans2_weightage : '',
            pol_ques_ans3 : '',
            pol_ques_ans3_weightage : '',
            business_segment : ''
        }
        this.saveQuestions = this.saveQuestions.bind(this);
        this.loadQuestions = this.loadQuestions.bind(this);
    }
    componentDidMount() {
        this.loadQuestions();
    }
    saveQuestions = (ques) => {
        ques.preventDefault();
        let question = {
            pol_ques_id : this.state.pol_ques_id,
            pol_ques_seq : this.state.pol_ques_seq,
            pol_ques_desc : this.state.pol_ques_desc,
            pol_ques_ans1 : this.state.pol_ques_ans1,
            pol_ques_ans1_weightage : this.state.pol_ques_ans1_weightage,
            pol_ques_ans2 : this.state.pol_ques_ans2,
            pol_ques_ans2_weightage : this.state.pol_ques_ans2_weightage,
            pol_ques_ans3 : this.state.pol_ques_ans3,
            pol_ques_ans3_weightage : this.state.pol_ques_ans3_weightage,
            business_segment : this.state.business_segment
        };
        PolicyQuestionsService.addPolicyQuestions(question).then(res => {
            this.setState({message : "Questions added successfully"});
            this.props.history.push("/questions");
        });
    }
}

export default EditPolicyQuestionsComponent;
