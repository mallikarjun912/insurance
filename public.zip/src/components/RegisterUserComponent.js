import React, { Component } from 'react';
import { connect } from 'react-redux';
import * as RegisterAction from '../store/actions/RegisterAction';
import { bindActionCreators } from 'redux';
//import { Link, Redirect } from 'react-router-dom';

class RegisterUserComponent extends Component {
    constructor(props){
        super(props)
        this.state = {
            username: '',
            password: '',
            role : ''
        }
        this.registerUser = this.registerUser.bind(this);
    }
    registerUser = (reg) => {
        let payload = {
            username : this.state.username,
            password : this.state.password,
            role : this.state.role
        }
        this.props.RegisterAction.doRegister(payload);
        reg.preventDefault();
    }
    onChange = (e) => this.setState({ [e.target.name]: e.target.value });
    render() {
      
        return(
            <div>
                <h1>New User Registration</h1>
                <form >
						<div className="form-group">
							<label>Enter Username</label>
							<input type="text" name="username" className="form-control" value={this.state.username} onChange={this.onChange} required></input><br></br>
							<label>Enter Password</label>
							<input type="text" name="password" className="form-control" value={this.state.password} onChange={this.onChange} required></input><br></br>
                            <label>Enter Role</label>
							<input type="text" name="role" className="form-control" value={this.state.role} onChange={this.onChange} required></input><br></br>
						</div>
						<button className="btn btn-success" onClick={this.registerUser}>Submit</button>
					</form>
            </div>
        );
    }
}

function mapStateToProps(state) {
    return {
        registration : state.RegnReducer.registration
    };
}

function mapDispatchToProps(dispatch){
    return {
        RegisterAction : bindActionCreators(RegisterAction,dispatch)
    };
}
export default connect(mapStateToProps,mapDispatchToProps) (RegisterUserComponent);