import axios from 'axios';

const ROLEURL = "http://localhost:8282/login";

class LoginService {
    getUser(username,password){
        return axios.get(ROLEURL+"/"+username+"/"+password);
    }
    registerUser(registration){
        return axios.post(""+ROLEURL,registration);
    }
}

export default new LoginService();
