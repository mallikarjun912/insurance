import axios from 'axios';

const REGURL = "http://localhost:8282/register";

export const registrationSuccess = () => {
    console.log("Inside register action");
    alert("User registered successfully...");
    //this.props.history.push("/login");
    window.location.href = "/login";
  
    return {
        type : "REG_SUCCESS"
    }
};

export const doRegister = (payload) => {
    console.log("Inside doRegister");
    let registration = {
        username : payload.username,
        password : payload.password,
        role : payload.role 
    }
    return (dispatch) => {
        return axios.post(REGURL+"/",registration)
        .then(Response => {
            console.log("api call");
            dispatch(registrationSuccess());
        })
        .catch(Error=>{
            console.log("error");
            throw(Error);
        });
    };
};