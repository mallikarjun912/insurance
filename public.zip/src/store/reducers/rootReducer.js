import { combineReducers } from 'redux';
import LoginReducer from './LoginReducer';
import RegnReducer from './RegnReducer';

const rootReducer = combineReducers({
    LoginReducer,
    RegnReducer
});

export default rootReducer;