const initialState = {
    registration : undefined
}

export default function RegnReducer(state= initialState,action) {
    switch (action.type) {
        case 'REG_SUCCESS':
            return {
                ...state,
                registration : action.registration
            };
    
        default:
            return state
    }
};
